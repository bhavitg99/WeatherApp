//
//  WeatherResponseController.swift
//  WeatherApp
//
//  Created by Bhavith Gunda on 22/04/21.
//

import UIKit

class WeatherResponseController: UITableViewController {

    var response: Result?
    var cityName: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.isNavigationBarHidden = false
        tableView.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationItem.title = ""
        self.tableView.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = cityName.capitalized
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if let detailView = segue.destination as? WeatherDetailViewController {
            guard let cell = sender as? UITableViewCell, let responseList = response?.list else { return }

            detailView.weatherInfo = responseList[cell.tag]
        }
        
    }
   

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return response?.list.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CellID") as? WeatherCell else {
            return UITableViewCell.init(style: .default, reuseIdentifier: "defualt")
        }
        cell.tag = indexPath.row
        if let info = response?.list[indexPath.row] {
            let weather = info.weather[0]
            cell.typeLabel.text = weather.main
            cell.tempLabel.text = "Temp: "+String(info.main.temp)
        }
        return cell
    }
}

class WeatherCell: UITableViewCell {
    
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
}
