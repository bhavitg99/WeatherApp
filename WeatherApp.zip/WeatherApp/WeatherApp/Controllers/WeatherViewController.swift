//
//  ViewController.swift
//  WeatherApp
//
//  Created by Bhavith Gunda on 22/04/21.
//

import UIKit

class WeatherViewController: UIViewController {

    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var lookupButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lookupButton.layer.borderColor = UIColor.gray.cgColor
        lookupButton.layer.borderWidth = 1.0
        lookupButton.layer.masksToBounds = true
        lookupButton.layer.cornerRadius = 15.0
        
        cityTextField.delegate = self
        lookupButton.isEnabled = false
        activityIndicator.stopAnimating()
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.title = ""
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        self.navigationItem.title = cityTextField.text?.capitalized

    }
    
    @IBAction func lookUpAction(_ sender: Any) {
        view.endEditing(true)
        activityIndicator.startAnimating()

        guard let cityName = cityTextField.text else {
            return
        }
        
        NetworkService.shared.getWeather(city: cityName) { (result) in
            self.updateUI(result)
        } onError: { (error) in
            print("Error \(error)")
            self.activityIndicator.stopAnimating()
            let alert = UIAlertController.init(title: "Error", message: error, preferredStyle: .alert)
            let action =  UIAlertAction(title: "Ok", style: .default) {_ in 
                self.cityTextField.text = ""
            }
            alert.addAction(action)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    func updateUI(_ response: Result) {
        activityIndicator.stopAnimating()

        self.navigationItem.title = cityTextField.text?.capitalized
        if let controller = self.storyboard?.instantiateViewController(identifier: "WeatherResponseControllerID") as? WeatherResponseController {
            controller.response = response
            controller.cityName = self.cityTextField.text ?? ""
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
}

extension WeatherViewController: UITextFieldDelegate {
    
     func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let textFieldText: NSString = (textField.text ?? "") as NSString
        let txtAfterUpdate = textFieldText.replacingCharacters(in: range, with: string) as NSString

        let length = txtAfterUpdate.length
        if length > 0 {
            lookupButton.isEnabled = true
        } else {
            lookupButton.isEnabled = false
        }
        return true
    }
    
     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return true
    }

}

