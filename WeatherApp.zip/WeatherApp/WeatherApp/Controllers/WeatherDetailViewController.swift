//
//  WeatherDetailViewController.swift
//  WeatherApp
//
//  Created by Bhavith Gunda on 22/04/21.
//

import UIKit

class WeatherDetailViewController: UIViewController {

    var weatherInfo: WeatherInfo?
    
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var feelsLikeTemp: UILabel!
    
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var descrptionLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let info = weatherInfo {
            tempLabel.text = String(info.main.temp)
            feelsLikeTemp.text = "Feels Like " + String(info.main.feels_like)
            let weather = info.weather[0]
            infoLabel.text = weather.main
            descrptionLabel.text = weather.description
        }
        // Do any additional setup after loading the view.
    }
    
}
