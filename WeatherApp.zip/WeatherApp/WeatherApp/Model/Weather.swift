//
//  Weather.swift
//  Weather
//
//  Created by Bhavith Gunda on 22/04/21.
//

import Foundation
/*
 "cod": "200",
   "message": 0,
   "cnt": 40,
   "list": [
     {
       "dt": 1619082000,
       "main": {
         "temp": 34.86,
         "feels_like": 37.26,
         "temp_min": 34.86,
         "temp_max": 37.83,
         "pressure": 1011,
         "sea_level": 1011,
         "grnd_level": 953,
         "humidity": 41,
         "temp_kf": -2.97
       },
       "weather": [
         {
           "id": 803,
           "main": "Clouds",
           "description": "broken clouds",
           "icon": "04d"
         }
       ],
       "clouds": {
         "all": 52
       },
       "wind": {
         "speed": 2.4,
         "deg": 90,
         "gust": 3.16
       },
       "visibility": 10000,
       "pop": 0,
       "sys": {
         "pod": "d"
       },
       "dt_txt": "2021-04-22 09:00:00"
     },
 **/
struct Result: Codable {
    let list: [WeatherInfo]
}

struct WeatherInfo: Codable {
    let main: Main
    let weather: [Weather]
    let clouds: Cloud
    let wind: Wind
}

struct Weather: Codable {
    let id: Int
    let main: String
    let description: String
    let icon: String
}

struct Main: Codable {

    let temp: Double
    let feels_like: Double
    let temp_min: Double
    let temp_max: Double
    let pressure: Int
    let humidity: Int
    let temp_kf: Double
    let sea_level: Double

}

struct Cloud: Codable {
    let all: Int
}

struct Wind: Codable {
    let speed: Double
    let deg: Int
}

struct Error: Codable {
    let cod: String
    let message: String

}
