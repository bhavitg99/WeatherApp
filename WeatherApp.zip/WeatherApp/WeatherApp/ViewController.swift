//
//  ViewController.swift
//  WeatherApp
//
//  Created by Kranthi Kumar Vodapelli on 22/04/21.
//

import UIKit

class WeatherViewController: UIViewController {

    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var lookupButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lookupButton.layer.borderColor = UIColor.gray.cgColor
        lookupButton.layer.borderWidth = 1.0
        lookupButton.layer.masksToBounds = true
        lookupButton.layer.cornerRadius = 10.0
        
    }

    @IBAction func lookUpAction(_ sender: Any) {
        
    }
    
}

