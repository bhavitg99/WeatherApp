//
//  NetworkService.swift
//  Weather
//
//  Created by Bhavith Gunda on 22/04/21.
//

import Foundation

class NetworkService {
    static let shared = NetworkService()
    
    //https://api.openweathermap.org/data/2.5/forecast?q=hyderabad&units=metric&appid=65d00499677e59496ca2f318eb68c049
    let URL_BASE = "https://api.openweathermap.org/data/2.5/forecast?"
    
    let session = URLSession(configuration: .default)
    
    func buildURL(_ city: String) -> String {
        return URL_BASE+"q=\(city)&units=metric&appid=65d00499677e59496ca2f318eb68c049"
    }
    
    
    func getWeather(city: String, onSuccess: @escaping (Result) -> Void, onError: @escaping (String) -> Void) {
        guard let url = URL(string: buildURL(city)) else {
            onError("Error building URL")
            return
        }
        
        let task = session.dataTask(with: url) { (data, response, error) in
            
            DispatchQueue.main.async {
                if let error = error {
                    onError(error.localizedDescription)
                    return
                }
                
                guard let data = data, let response = response as? HTTPURLResponse else {
                    onError("Invalid data or response")
                    return
                }
                
                do {
                    if response.statusCode == 200 {
                        let items = try JSONDecoder().decode(Result.self, from: data)
                        onSuccess(items)
                    } else {
                        let error = try JSONDecoder().decode(Error.self, from: data)
                        onError(error.message)
                    }
                } catch {
                    onError(error.localizedDescription)
                }
            }
            
        }
        task.resume()
    }
    
}
